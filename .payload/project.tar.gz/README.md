# MineFinds

Private Android Minecraft coordinate journal.

## What it does
- Saves multiple worlds with seed, edition, version, and dimension.
- Permanently stores X/Y/Z finds and notes in SQLite.
- Remembers your last entered current coordinates per world.
- Sorts saved finds nearest to farthest.
- Opens Chunkbase Seed Map centered on your current position or a saved find.
- Edit/delete individual finds; delete a world only with confirmation.

## Android Studio
Open the project folder in Android Studio, let Gradle sync, then Build > Build APK(s).

## GitHub Actions
If this project is put in its own GitHub repository, `.github/workflows/build-apk.yml` builds a debug APK and uploads it as `MineFinds-APK`.
